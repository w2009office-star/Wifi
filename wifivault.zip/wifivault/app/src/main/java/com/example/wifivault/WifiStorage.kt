package com.example.wifivault

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Penyimpanan lokal (hanya di HP ini, tidak dikirim ke mana pun).
 * Data disimpan sebagai JSON array di dalam SharedPreferences.
 *
 * Catatan privasi: file ini TIDAK membaca password WiFi sistem. Semua
 * password berasal dari input manual pengguna lewat UI aplikasi.
 */
class WifiStorage(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAll(): List<WifiNetwork> {
        val raw = prefs.getString(KEY_DATA, null) ?: return emptyList()
        val arr = JSONArray(raw)
        val list = mutableListOf<WifiNetwork>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                WifiNetwork(
                    ssid = obj.getString("ssid"),
                    password = obj.getString("password"),
                    updatedAt = obj.optLong("updatedAt", 0L)
                )
            )
        }
        // Terbaru diubah tampil di atas
        return list.sortedByDescending { it.updatedAt }
    }

    /** Menambah jaringan baru, atau memperbarui password jika SSID sudah ada. */
    fun upsert(network: WifiNetwork) {
        val current = getAll().filterNot { it.ssid == network.ssid }.toMutableList()
        current.add(network)
        saveAll(current)
    }

    fun delete(ssid: String) {
        val current = getAll().filterNot { it.ssid == ssid }
        saveAll(current)
    }

    fun find(ssid: String): WifiNetwork? = getAll().firstOrNull { it.ssid == ssid }

    private fun saveAll(list: List<WifiNetwork>) {
        val arr = JSONArray()
        list.forEach {
            val obj = JSONObject()
            obj.put("ssid", it.ssid)
            obj.put("password", it.password)
            obj.put("updatedAt", it.updatedAt)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_DATA, arr.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "wifi_vault_prefs"
        private const val KEY_DATA = "wifi_vault_data"
    }
}
