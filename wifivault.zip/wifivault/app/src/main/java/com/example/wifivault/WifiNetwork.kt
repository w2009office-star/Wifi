package com.example.wifivault

/**
 * Satu catatan jaringan WiFi yang disimpan pengguna secara manual.
 * ssid   : nama jaringan WiFi
 * password : password yang diketik pengguna sendiri
 * updatedAt: kapan terakhir disimpan/diubah (epoch millis)
 */
data class WifiNetwork(
    val ssid: String,
    val password: String,
    val updatedAt: Long = System.currentTimeMillis()
)
