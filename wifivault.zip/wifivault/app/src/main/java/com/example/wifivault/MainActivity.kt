package com.example.wifivault

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var storage: WifiStorage
    private lateinit var adapter: NetworkAdapter
    private lateinit var tvCurrentSsid: TextView

    private val locationPermissionRequestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        storage = WifiStorage(this)

        tvCurrentSsid = findViewById(R.id.tvCurrentSsid)
        val btnSaveCurrent = findViewById<android.widget.Button>(R.id.btnSaveCurrent)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val fabAdd = findViewById<FloatingActionButton>(R.id.fabAdd)

        adapter = NetworkAdapter(
            items = storage.getAll(),
            onCopy = { copyPassword(it) },
            onEdit = { showAddEditDialog(existing = it) },
            onDelete = { confirmDelete(it) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fabAdd.setOnClickListener { showAddEditDialog(existing = null) }

        btnSaveCurrent.setOnClickListener {
            val ssid = getCurrentSsid()
            if (ssid.isNullOrBlank()) {
                Toast.makeText(this, "Tidak terhubung ke WiFi, atau izin lokasi belum diberikan.", Toast.LENGTH_LONG).show()
            } else {
                showAddEditDialog(existing = storage.find(ssid) ?: WifiNetwork(ssid, ""))
            }
        }

        ensureLocationPermission()
        refreshCurrentSsid()
    }

    override fun onResume() {
        super.onResume()
        refreshCurrentSsid()
        refreshList()
    }

    private fun refreshList() {
        adapter.updateData(storage.getAll())
    }

    private fun refreshCurrentSsid() {
        val ssid = getCurrentSsid()
        tvCurrentSsid.text = if (ssid.isNullOrBlank()) {
            "Tidak terhubung ke WiFi"
        } else {
            "Tersambung ke: $ssid"
        }
    }

    /**
     * Mengambil nama WiFi (SSID) yang sedang aktif.
     * Ini HANYA membaca nama jaringan, bukan password - Android tidak
     * mengizinkan aplikasi membaca password WiFi yang tersimpan di sistem.
     */
    private fun getCurrentSsid(): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wifiManager.connectionInfo ?: return null
        var ssid = info.ssid ?: return null
        if (ssid == "<unknown ssid>" || ssid.isBlank()) return null
        if (ssid.startsWith("\"") && ssid.endsWith("\"")) {
            ssid = ssid.substring(1, ssid.length - 1)
        }
        return ssid
    }

    private fun ensureLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                locationPermissionRequestCode
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionRequestCode) {
            refreshCurrentSsid()
        }
    }

    private fun showAddEditDialog(existing: WifiNetwork?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_edit, null)
        val etSsid = view.findViewById<EditText>(R.id.etSsid)
        val etPassword = view.findViewById<EditText>(R.id.etPassword)

        etSsid.setText(existing?.ssid ?: "")
        etPassword.setText(existing?.password ?: "")
        etPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD

        // Kalau sedang edit dari WiFi yang sedang aktif, SSID dikunci agar tidak salah ketik
        if (existing != null && existing.ssid == getCurrentSsid()) {
            etSsid.isEnabled = false
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing != null && storage.find(existing.ssid) != null) "Edit Password WiFi" else "Simpan WiFi Baru")
            .setView(view)
            .setPositiveButton("Simpan") { _, _ ->
                val ssid = etSsid.text.toString().trim()
                val password = etPassword.text.toString()
                if (ssid.isEmpty()) {
                    Toast.makeText(this, "Nama WiFi tidak boleh kosong.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                storage.upsert(WifiNetwork(ssid = ssid, password = password))
                refreshList()
                Toast.makeText(this, "Tersimpan.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmDelete(network: WifiNetwork) {
        AlertDialog.Builder(this)
            .setTitle("Hapus catatan?")
            .setMessage("Catatan WiFi \"${network.ssid}\" akan dihapus dari HP ini.")
            .setPositiveButton("Hapus") { _, _ ->
                storage.delete(network.ssid)
                refreshList()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun copyPassword(network: WifiNetwork) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("password_wifi", network.password))
        Toast.makeText(this, "Password \"${network.ssid}\" disalin.", Toast.LENGTH_SHORT).show()
    }
}
