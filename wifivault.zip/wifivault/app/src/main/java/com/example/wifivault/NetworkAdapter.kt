package com.example.wifivault

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NetworkAdapter(
    private var items: List<WifiNetwork>,
    private val onCopy: (WifiNetwork) -> Unit,
    private val onEdit: (WifiNetwork) -> Unit,
    private val onDelete: (WifiNetwork) -> Unit
) : RecyclerView.Adapter<NetworkAdapter.VH>() {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
    private val revealed = mutableSetOf<String>()

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val ssid: TextView = view.findViewById(R.id.tvSsid)
        val password: TextView = view.findViewById(R.id.tvPassword)
        val updated: TextView = view.findViewById(R.id.tvUpdated)
        val btnShow: ImageButton = view.findViewById(R.id.btnShow)
        val btnCopy: ImageButton = view.findViewById(R.id.btnCopy)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEdit)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_network, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.ssid.text = item.ssid
        holder.updated.text = "Diperbarui: ${dateFormat.format(Date(item.updatedAt))}"

        val isRevealed = revealed.contains(item.ssid)
        holder.password.text = if (isRevealed) item.password else "•".repeat(item.password.length.coerceAtLeast(6))

        holder.btnShow.setOnClickListener {
            if (isRevealed) revealed.remove(item.ssid) else revealed.add(item.ssid)
            notifyItemChanged(position)
        }
        holder.btnCopy.setOnClickListener { onCopy(item) }
        holder.btnEdit.setOnClickListener { onEdit(item) }
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<WifiNetwork>) {
        items = newItems
        notifyDataSetChanged()
    }
}
