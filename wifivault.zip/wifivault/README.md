# WiFi Vault

Aplikasi Android pribadi untuk mencatat SSID + password WiFi yang kamu simpan sendiri secara manual, tersimpan **lokal di HP** (tidak dikirim ke server mana pun).

## Kenapa password harus diketik manual sekali?

Sejak Android 8 (Oreo), sistem **mengunci akses aplikasi pihak ketiga ke password WiFi yang tersimpan**, demi keamanan pengguna. Tidak ada aplikasi non-root yang bisa membaca password WiFi secara otomatis dari sistem — ini berlaku untuk semua aplikasi, bukan cuma aplikasi ini.

Yang aplikasi ini **bisa** lakukan:
- Mendeteksi nama WiFi (SSID) yang sedang aktif
- Menyimpan password yang kamu ketik, terhubung ke SSID itu
- Menampilkan, menyalin (copy), mengedit, dan menghapus catatan kapan saja
- Kalau password WiFi berubah, cukup edit sekali di aplikasi — tidak perlu catat ulang di tempat lain

## Cara upload ke GitHub dari HP

1. Buat repository baru di GitHub (lewat browser HP), misalnya `wifi-vault`.
2. Install aplikasi **Working Copy** (iOS) atau **Termux + git** / aplikasi **GitHub** resmi / **ISH** (Android) untuk push dari HP. Cara termudah di Android: install **Termux**, lalu:
   ```
   pkg install git
   git clone <url-repo-kosong-kamu>
   # salin semua file project ini ke folder hasil clone
   cd wifi-vault
   git add .
   git commit -m "Initial commit: WiFi Vault app"
   git push
   ```
3. Setelah push, buka tab **Actions** di repo GitHub kamu — workflow "Build APK" akan otomatis jalan.
4. Setelah selesai (beberapa menit), buka hasil run tersebut, scroll ke bagian **Artifacts**, unduh `wifi-vault-debug-apk`.
5. Ekstrak zip-nya, install file `app-debug.apk` di HP (aktifkan "Install dari sumber tidak dikenal" kalau diminta).

## Izin yang diminta aplikasi

- **Lokasi (ACCESS_FINE_LOCATION)**: wajib dari sistem Android untuk bisa membaca *nama* WiFi yang aktif. Aplikasi ini tidak melacak atau menyimpan lokasi kamu sama sekali — izin ini hanya dipakai untuk fitur "deteksi WiFi aktif".

## Struktur project

```
app/src/main/java/com/example/wifivault/
  MainActivity.kt      -> layar utama
  WifiStorage.kt        -> penyimpanan lokal (SharedPreferences)
  WifiNetwork.kt         -> model data
  NetworkAdapter.kt      -> tampilan daftar
app/src/main/res/        -> layout & tampilan
.github/workflows/build.yml -> otomatis build APK saat push
```
